% input : 
% example store in : data.mat
% K: camera intrinsic matrix 
% imgDepth: depth map 
% Rtilt: Rotation matrix to align the point could on gravity direction, for
% a room layout the Rtilt can be estimate from [Rtilt,R] = rectify(XYZ);

% Output : 
% featureTest : MxNxKx300 matrix
% SpaceTest : point cloud range
% bincellDim : [M N K]
% cellInsight : indicate whether each cell completely inside view of field
% partailInsight : indicate whether each cell partially inside view of field
% occcell : whether each cell is occluded or not 
% missDepthcell : whether this cell is missing depth
% pointCount : number of points in each cell
% pointCountIntegral : 3D integral image of pointCount
% occSource = for each occluded cell what's the depth of occluder 


addpath(genpath('.'))
clear all

load('data.mat') 

featurepara.featype ='pointtsdfnormalshape'; 
featurepara.s =0.1;
featurepara.normalize=0;
featurepara.highdim=0;

crop = [1,1];
[rgb,XYZworldframe] = read_3d_pts_general(imgDepth,K,size(imgDepth),[],crop);
XYZworldframe = (Rtilt*XYZworldframe')';
[featureTest,SpaceTest,bincellDim,cellInsight,partailInsight,occcell,missDepthcell,pointCountIntegral,pointCount,occSource]...
            = mFeature_combined(imgDepth,XYZworldframe,featurepara.s,Rtilt,crop,[],featurepara,[0,0,0],0);

