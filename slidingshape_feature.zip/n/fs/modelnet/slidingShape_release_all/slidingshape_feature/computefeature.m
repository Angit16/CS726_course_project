function computefeature(Rtilt,imgDepth,K)
% Example code to compute features on RMRC dataset (provide 'dataset_detection3d_test.mat').
% The features compute using refined depth map are stored in
% '../NYUdatafeature_release/'

[~,featurepara]=setParameters();
crop = [1,1];
[rgb,XYZworldframe] = read_3d_pts_general(depth,K,size(depth),[],crop);
XYZworldframe = (Rtilt*XYZworldframe')';
[featureTest,SpaceTest,bincellDim,cellInsight,partailInsight,occcell,missDepthcell,pointCountIntegral,pointCount,occSource,pointRange]...
            = mFeature_combined(imgDepth,XYZworldframeTest,featurepara.s,Rtilt,[],[],featurepara,[0,0,0],imageNum);


   

end


